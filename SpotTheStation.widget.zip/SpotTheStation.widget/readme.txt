Spot The Station Widget for Übersicht

More info at https://github.com/larkov/Uebersicht-SpotTheStationWidget